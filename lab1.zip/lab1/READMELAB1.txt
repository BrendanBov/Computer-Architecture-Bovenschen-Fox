use the "runall" executable to simulate each memfile
NOTE: 'g' must still be used to run each and 'q' to exit